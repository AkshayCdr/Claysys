﻿using System.Reflection.Metadata.Ecma335;

namespace crud.Models.Domain
{
    public class Employee
    {
        public Guid Id { get; set; }
        public string Name{ get; set; }
        public string Email { get; set; }
        public long Salary { get; set; }
        public int MyProperty { get; set; }
        public DateTime DateOfBirth { get; set; }
        public String Departement { get; set;}

    }
}
